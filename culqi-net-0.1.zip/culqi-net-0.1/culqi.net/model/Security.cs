﻿using System;
namespace culqi.net
{
	public class Security
	{	
		public Security()
		{
		}

		public string code_commerce{ get; set; }
		public string api_key{ get; set; }

	}
}
